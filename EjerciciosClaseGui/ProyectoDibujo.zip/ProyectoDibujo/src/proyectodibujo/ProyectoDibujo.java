package proyectodibujo;

/**
 * @author mauricio
 */

public class ProyectoDibujo {
    public static void main(String[] args) {

        
        // uso : al redimensionar la ventana, el dibujo cambia de forma aleatoria entre varias transformaciones de goku
        gokuFrame frame = new gokuFrame();
        frame.setVisible(true);
    }
    
}
