package CapaPresentacion;


/*@author mauricio*/


public class App01 {

    public static void main(String[] args) {

        
        NewJDialog ventana =  new NewJDialog(null,true);
        ventana.setLocationRelativeTo(ventana);
        ventana.setVisible(true);
    }
    
}
